<?php
include "header.php";
?>
    <div id="right-panel" class="right-panel">

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>

        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <img src="yoga_women.jpg" alt="">
                                </div>
                        </div> <!-- .card -->   
                    </div>
                    <!--/.col-->

                </div><!-- .animated -->
            </div><!-- .content -->
<?php
include "footer.php";
?>       